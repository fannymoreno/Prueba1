/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba1_2019;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Estefanie
 */
public class Conectar {
    //Connection ya existe, debemos importarla
    private static Connection conn;
    //crearé variables driver, user, password, url
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user= "root";
    private static final String password = "";
    //direccion/referencia donde está mi base de datos, iguel al nombre creado en mysql
    private static final String url = "jdbc:mysql://localhost:3306/prueba2019";

    
    //metodo constructor
    public Conectar() {
        conn = null;
        try{
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);
            if(conn != null){
                System.out.println("Conexión Establecida.");
            }
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Error al Conectar "+e);
        }
    }
     
    //este metodo nos retorna la conexion
    public Connection getConnection(){
        return conn;
    }
    
    //con este metodo nos desconectamos de la base de datos
    public void desconectar(){
        conn = null;
        if(conn == null){
            System.out.println("Conexión Terminada.");
        
        }
    
    }
    
}





