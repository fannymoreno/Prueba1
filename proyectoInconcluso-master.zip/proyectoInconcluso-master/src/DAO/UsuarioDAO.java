/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Usuario;
import prueba1_2019.Conectar;

/**
 *
 * @author Estefanie
 */
public class UsuarioDAO {
    private final String SQL_INSERT = "INSERT INTO usuario(id_usuario, nombre) values(?,?)";
    private final String SQL_SELECT = "SELECT * FROM usuario WHERE id like ......";
    private PreparedStatement PS;
    private DefaultTableModel DT; 
    private ResultSet RS;
    private Conectar CN; 
    
    public UsuarioDAO() {
        PS = null;
        CN = new Conectar();  
    }
    
     public void getUsuario(int id){
       String SQL;
       SQL="SELECT * FROM usuario WHERE id_usuario like '" + id + "%'";
       try{
           PS= CN.getConnection().prepareStatement(SQL);
           RS= PS.executeQuery();
           while(RS.next()){
               Usuario us = new Usuario();
               us.setId_usuario(RS.getInt(1));
               us.setNombre(RS.getString(2));
           }
       }catch(SQLException e){
           System.err.println(" Error al listar los datos: "+e.getMessage());
       }
       finally{
           PS= null;
           RS= null;
       }
     }
     
     
    
   //public ArrayList<Usuario> getUsuarios(){
      
    //}
     
    public int insertDatos(int id, String nombre){
       int res=0;
       try{
           PS = CN.getConnection().prepareStatement(SQL_INSERT);
           PS.setInt(1,id);
           PS.setString(2, nombre);
           res = PS.executeUpdate();
           if(res >0){
           JOptionPane.showMessageDialog(null, "Registro Guardado.");
           }
       }catch(SQLException e){
           System.err.println("Error al guardar los datos: "+e.getMessage());
       } finally{
           PS = null;
       }
       return res;
   }
    
 
}
