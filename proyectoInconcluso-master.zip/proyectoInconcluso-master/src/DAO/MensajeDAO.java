
package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.Mensaje;
import modelo.Usuario;
import prueba1_2019.Conectar;

/**
 *
 * @author Estefanie
 */
public class MensajeDAO {
    private final String SQL_INSERT = "INSERT INTO mensaje(id_mensaje, contenido) values(?,?)";
    private final String SQL_SELECT = "SELECT * FROM mensaje";
    private PreparedStatement PS;
    private DefaultTableModel DT; 
    private ResultSet RS;
    private Conectar CN; 
    
    
    
    public MensajeDAO() {
        PS = null;
        CN = new Conectar();  
    }
    
    public void getMensaje(int id){
      String SQL;
       SQL="SELECT * FROM mensaje WHERE id_usuario like '" + id + "%'";
       try{
           PS= CN.getConnection().prepareStatement(SQL);
           RS= PS.executeQuery();
           while(RS.next()){
               Mensaje msj = new Mensaje();
               msj.setId_mensaje(RS.getInt(1));
               msj.setContenido(RS.getString(2));
           }
       }catch(SQLException e){
           System.err.println(" Error al listar los datos: "+e.getMessage());
       }
       finally{
           PS= null;
           RS= null;
       }
    }
    
    
}
